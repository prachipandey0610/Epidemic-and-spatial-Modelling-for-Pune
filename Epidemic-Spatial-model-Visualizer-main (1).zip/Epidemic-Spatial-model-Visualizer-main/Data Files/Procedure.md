sum, subtract 4,50,000 , divide by 16 , add to these 16 blocks,

-----

189,214,190,215,212,236

---

---

---

133
149
150
163
164
165
166
184
185
186
207
208
209
232
233
256

Added 24307 to these.

---

Minimum Added 1500 to all cells

---

# Cell addition macro 

```Excel Macro
Sub AddValueToCells()
    For Each Mycell In Selection
        Mycell.Activate
       ActiveCell.FormulaR1C1 = "= " & ActiveCell.Formula & "+100"
   Next Mycell
End Sub
```



# SSH Commands

```ssh
ssh -N -L localhost:8888:localhost:8888 mrdgh2821@192.168.1.12

ssh mrdgh2821@192.168.1.12
```

---

## Swaps

#### Destination -
72<-462
131<-463
135<-456
304<-448

#### Source -
- [x] 462->72
- [x] 463->131
- [x] 456->135
- [x] 448->304
- [x] 497->313

#### Other Destinations

138
142
207
208
209
210
215
216
232
233
237
261
278
287
301
356
357
518

---

## After swapping - 

Population = 2212412

Goal = 3100000

Remaining = 887588

---

### Add stuff -
- [x] 207
- [x] 208
- [x] 209
- [x] 210

1 lac distributed.

----

787588 lakh population pending

##### Add 50000 -

- [x] 131	
- [x] 232
- [x] 233	
- [x] 234	
- [x] 278	
- [x] 301		

3,00,000 Distributed

Population = 2612412

Goal = 3100000

Remaining = 487588

----------------
#### Sub orange 
---

Ignore these for sub orange category

255
237
261
287
138
166

---
163 
164
166
183
184
187
211
230
255

---

Asked Rashi -

Bibwewadi - (1 lacs) (distribute the population. don’t make it equally distributed.)

212 
236

(upper & lower) left side - put some population
put more in lower left side
(in the reference)
Find hotspots and fill

---------------------

### Bibwewadi Areas (Putting 1 lakh)

#### Distribute 68000 (17000 to all 4)

- [x] 212 (14678 Added)
- [x] 213 (19322 Added)
- [x] 236 (15647 Added)
- [x] 260 (18353 Added)

#### Distribute some less i.e. 32000 (8000 to all 4)
- [x] 237 (4500 added)
- [x] 238 (3500 added)
- [x] 261 (3800 added)
- [x] 262 (4200 added)

--------

#### Swap operation

- [x] 375->290

- [x] 261->211

----

Population = 2696412

Goal = 3100000

Remaining = 403588

----

### Upper Left Pune (90k)

- [x] 72 (give more here) (17k)

- [x] 73 (14290)

- [x] 74 (14280)

- [x] 55 (14385)

- [x] 56 (14285)

- [x] 57 (14185)

- [x] 42 (14485)

- [x] 41 (14085)

---

### Lower Left Pune (1.2 Lakh)

- [x] 78 (10K)

- [x] 79 (10K) 

- [x] 97 (9K)

- [x] 98 (11K)

- [x] 81 (10K)

- [x] 131 (10K)

- [x] 132 (10K)

- [x] 138 (10K)

- [x] 139 (10K)

- [x] 147 (10K)

- [x] 149 (10K)

- [x] 151 (10K)

---

Population = 2933407

Goal = 3100000

Remaining = 166593

----

### Bibwewadi Update 

Distribute 1.2 lakhs 

- [x] 287 (55k)

- [x] 288 (32000)

- [x] 312 (33000)

Population = 3053407

Goal = 3100000

Remaining = 46593

---

### Swap

- [x] 468 -> 100

- [x] 469 -> 118

- [x] 470 -> 119

- [x] 471 -> 102

- [x] 472 -> 121 (added 3000)

- [x] 473 -> 122
- [x] 474 -> 123

---

#### Add 1000

- [x] 345
- [x] 346

----

Population = 3058407

Goal = 3100000

Remaining = 41593

---

### The Confusion:

Critical mass of people when pop is less, it eats up all



But when critical mass goes up, it doesn’t eat up all the people. 

+ we have less mobility data